<?php
/* * 亲，如果您喜欢本主题或者有任何意见，请上http://www.wpmomo.com发表留言 */

wp_footer();
?>
</body>
</html>
